def helloworld(name):
   print("Hello "+name)